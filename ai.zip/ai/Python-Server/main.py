import os
import cv2
import numpy as np
import base64
import threading
import time
import paramiko
import shutil
from flask import Flask, request, jsonify, send_file
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import mysql.connector
from mysql.connector import Error
import pymysql

app = Flask(__name__)

KNOWN_FACES_DIR = "faces"
UPLOAD_FOLDER = "uploads"
RESULT_FILE = "result.txt"

# SSH Config
HOST = "10.10.10.130"
USERNAME = "docker-master"
PASSWORD = "docker-master"
REMOTE_DIR = "/home/docker-master/projectwork/app/output"

face_recognizer = cv2.face.LBPHFaceRecognizer_create()
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

def load_known_faces():
    images, labels, label_map, reverse_map, label_id = [], [], {}, {}, 0
    for filename in sorted(os.listdir(KNOWN_FACES_DIR)):
        img_path = os.path.join(KNOWN_FACES_DIR, filename)
        image = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        faces = face_cascade.detectMultiScale(image, 1.1, 5)
        if len(faces) > 0:
            x, y, w, h = faces[0]
            images.append(image[y:y+h, x:x+w])
            labels.append(label_id)

            basename = os.path.splitext(filename)[0]
            label_map[label_id] = basename
            reverse_map[basename] = label_id

            label_id += 1
    if images:
        face_recognizer.train(images, np.array(labels))

    return label_map  # 🔴 MANCAVA QUESTO 

def reload_faces():
    global face_recognizer, LABEL_MAP
    face_recognizer = cv2.face.LBPHFaceRecognizer_create()
    LABEL_MAP = load_known_faces()
    print("[MODELLO] Volti ricaricati con successo.")
    return LABEL_MAP

LABEL_MAP = reload_faces()


def create_usersdb_connection():
    try:
        connection = pymysql.connect(
            host='10.10.10.130',
            user='flaskuser',
            password='flaskpass',
            database='usersdb',
        )
        print("Connessione a UsersDB riuscita")
        return connection
    except pymysql.MySQLError as e:
        print(f"Errore durante la connessione a UsersDB: {e}")
        return None

def recognize_face(image):
    faces = face_cascade.detectMultiScale(image, 1.05, 3)

    if len(faces) == 0:
        print("[DEBUG] Nessun volto rilevato.")
        user_id = 1
        badge_id = get_badge_id(user_id) or 1
        log_user_access(user_id, badge_id, "fallito")
        return "Volto non rilevato"

    x, y, w, h = faces[0]
    label, confidence = face_recognizer.predict(image[y:y+h, x:x+w])
    print(f"[DEBUG] Volto rilevato. label={label}, confidenza={confidence:.2f}")

    if confidence < 70:
        try:
            user_id = int(LABEL_MAP[label])
            print(f"[DEBUG] LABEL_MAP[{label}] = {LABEL_MAP[label]} → user_id = {user_id}")
        except (ValueError, KeyError) as e:
            print(f"[ERRORE] LABEL_MAP[{label}] non valido: {e}")
            user_id = 1

        badge_id = get_badge_id(user_id)
        if badge_id is None:
            print(f"[ERRORE] Nessun badge trovato per User_Id={user_id}, fallback a 1")
            badge_id = 1

        log_user_access(user_id, badge_id, "riuscito")
        return f"Riconosciuto: {LABEL_MAP[label]} (confidenza: {confidence:.2f})"

    else:
        print(f"[DEBUG] Confidenza troppo alta: {confidence:.2f}, considerato fallito")
        user_id = 1
        badge_id = get_badge_id(user_id) or 1
        log_user_access(user_id, badge_id, "fallito")
        return f"Volto non riconosciuto (confidenza: {confidence:.2f})"

def get_badge_id(user_id):
    conn = create_usersdb_connection()
    if not conn:
        print("[ERRORE] Connessione fallita in get_badge_id")
        return None
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT Id FROM Badges WHERE User_Id = %s LIMIT 1", (user_id,))
        result = cursor.fetchone()
        if result:
            print(f"[DEBUG] Badge_Id per User_Id {user_id} = {result[0]}")
            return result[0]
        else:
            print(f"[DEBUG] Nessun Badge_Id trovato per User_Id {user_id}")
            return None
    except Exception as e:
        print(f"[ERRORE] Errore nel recupero Badge_Id: {e}")
        return None
    finally:
        conn.close()

def log_user_access(user_id, badge_id, status):
    conn = create_usersdb_connection()
    if not conn:
        print("[ERRORE] Connessione fallita in log_user_access")
        return
    try:
        cursor = conn.cursor()

        cursor.execute("SELECT Id FROM Photos WHERE User_Id = %s LIMIT 1", (user_id,))
        photo_row = cursor.fetchone()

        if not photo_row:
            print(f"[ERRORE] Nessuna foto trovata per User_Id={user_id}.")
            return

        photo_id = photo_row[0]
        print(f"[DEBUG] Photo_Id per User_Id {user_id} = {photo_id}")
        print(f"[DEBUG] Inserimento in User_Accesses → status: {status}, photo_id: {photo_id}, badge_id: {badge_id}")

        cursor.execute(
            "INSERT INTO User_Accesses (Status, Created_At, Updated_At, Photo_Id, Badge_Id) "
            "VALUES (%s, NOW(), NOW(), %s, %s)",
            (status, photo_id, badge_id)
        )
        conn.commit()
        print(f"[DB] Accesso registrato correttamente ✅")

    except Exception as e:
        print(f"[ERRORE] Inserimento accesso fallito: {e}")
    finally:
        conn.close()

# 📦 API /upload
@app.route('/upload', methods=['POST'])
def upload_image():
    # Se è un'immagine binaria (es. da Arduino)
    if request.content_type == 'image/jpeg':
        try:
            image_data = request.data

            # Salva immagine originale per debug
            with open(os.path.join(UPLOAD_FOLDER, "debug_upload.jpg"), "wb") as f:
                f.write(image_data)

            image_np = np.frombuffer(image_data, np.uint8)
            image = cv2.imdecode(image_np, cv2.IMREAD_GRAYSCALE)
        except Exception as e:
            response = f"Errore nella decodifica immagine binaria: {str(e)}"
            with open(RESULT_FILE, "w") as f:
                f.write(response)
            return jsonify({"error": response}), 400

    # Altrimenti, gestisci come JSON base64
    elif request.is_json:
        data = request.get_json()
        if 'image_base64' not in data:
            response = "Errore: campo 'image_base64' mancante"
            with open(RESULT_FILE, "w") as f:
                f.write(response)
            return jsonify({"error": response}), 400
        try:
            image_data = base64.b64decode(data['image_base64'])

            # Salva immagine originale per debug
            with open(os.path.join(UPLOAD_FOLDER, "debug_upload.jpg"), "wb") as f:
                f.write(image_data)

            image_np = np.frombuffer(image_data, np.uint8)
            image = cv2.imdecode(image_np, cv2.IMREAD_GRAYSCALE)
        except Exception as e:
            response = f"Errore nella decodifica base64: {str(e)}"
            with open(RESULT_FILE, "w") as f:
                f.write(response)
            return jsonify({"error": response}), 400

    else:
        response = "Tipo di contenuto non supportato. Usa image/jpeg o JSON base64."
        with open(RESULT_FILE, "w") as f:
            f.write(response)
        return jsonify({"error": response}), 415

    result = recognize_face(image)
    with open(RESULT_FILE, "w") as f:
        f.write(result)

    return jsonify({"result": result})

@app.route('/result', methods=['GET'])
def get_result():
    return send_file(RESULT_FILE) if os.path.exists(RESULT_FILE) else ("Nessun risultato disponibile", 404)

class UploadHandler(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory and event.src_path.endswith(".jpg"):
            time.sleep(1)
            image = cv2.imread(event.src_path, cv2.IMREAD_GRAYSCALE)
            if image is not None:
                result = recognize_face(image)
                with open(RESULT_FILE, "w") as f:
                    f.write(result)
                # os.remove(event.src_path)

def start_watcher():
    observer = Observer()
    observer.schedule(UploadHandler(), UPLOAD_FOLDER, recursive=False)
    observer.start()
    observer.join()

def process_instruction(ssh):
    sftp = ssh.open_sftp()
    remote_instruction = f"{REMOTE_DIR}/instruction.txt"
    try:
        local_instruction = "instruction.txt"
        sftp.get(remote_instruction, local_instruction)
        with open(local_instruction, "r") as f:
            instruction = f.read().strip()
        os.remove(local_instruction)

        if instruction.startswith("add"):
            _, filename = instruction.split()
            remote_image = f"{REMOTE_DIR}/{filename}"
            local_path = os.path.join(KNOWN_FACES_DIR, filename)
            sftp.get(remote_image, local_path)
            print(f"[SSH] Immagine aggiunta: {filename}")
            reload_faces()

        elif instruction.startswith("delete"):
            _, filename = instruction.split()
            local_path = os.path.join(KNOWN_FACES_DIR, filename)
            if os.path.exists(local_path):
                os.remove(local_path)
                print(f"[SSH] Immagine eliminata: {filename}")
            reload_faces()

        for file in sftp.listdir(REMOTE_DIR):
            sftp.remove(f"{REMOTE_DIR}/{file}")
            print(f"[SSH] File remoto rimosso: {file}")

    except FileNotFoundError:
        pass
    except Exception as e:
        print(f"Errore elaborazione istruzione: {e}")
    finally:
        sftp.close()

def watch_remote_folder():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(HOST, username=USERNAME, password=PASSWORD)
        print("[SSH] Connesso al server remoto")
        while True:
            process_instruction(ssh)
            time.sleep(5)
    except Exception as e:
        print(f"Errore SSH: {e}")
    finally:
        ssh.close()

if __name__ == '__main__':
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(KNOWN_FACES_DIR, exist_ok=True)
    threading.Thread(target=start_watcher, daemon=True).start()
    threading.Thread(target=watch_remote_folder, daemon=True).start()
    app.run(host='0.0.0.0', port=5000)